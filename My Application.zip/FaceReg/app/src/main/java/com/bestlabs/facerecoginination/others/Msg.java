package com.bestlabs.facerecoginination.others;

import android.util.Log;

public class Msg {
    public static void log(String message) {
        Log.d("FACEAPP",message);
    }
}
