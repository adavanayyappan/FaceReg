package com.bestlabs.facerecoginination.ui.leave;

import androidx.lifecycle.ViewModel;

public class LeaveViewModel extends ViewModel {

    public LeaveViewModel() {
    }
}