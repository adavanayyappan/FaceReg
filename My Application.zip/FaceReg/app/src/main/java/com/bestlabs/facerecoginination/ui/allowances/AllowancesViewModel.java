package com.bestlabs.facerecoginination.ui.allowances;

import androidx.lifecycle.ViewModel;

public class AllowancesViewModel extends ViewModel {

    public AllowancesViewModel() {

    }

}